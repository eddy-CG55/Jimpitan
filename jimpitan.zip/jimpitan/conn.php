<?php

$kon = mysqli_connect("localhost","root","","bisa");
$kod = mysqli_query($kon, "SELECT * FROM anggota");


if (!$kod) {
	die("tidak terhubung" .mysql_error());
}

 ?>
