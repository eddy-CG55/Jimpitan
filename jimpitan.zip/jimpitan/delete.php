<?php 

require 'index.php';

 $id =$_GET['id'];
 
 if(isset($id)) {
 
  mysqli_query($kon,"DELETE FROM anggota WHERE id = '$id'");
  echo '<script language="javascript" type="text/javascript">
  alert("data berhasil di hapus!");</script>';
  echo "<meta http-equiv='refresh' content='2; url=index.php'>";

}

?>