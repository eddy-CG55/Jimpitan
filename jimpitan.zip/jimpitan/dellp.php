<?php 

require 'laporan.php';

$id =$_GET['id_l'];
// var_dump($id);
 
 if(isset($id)) {
 
  mysqli_query($kon,"DELETE FROM laporan WHERE id = '$id'");
 echo "<meta http-equiv='refresh' content='2; url=index.php'>";
}

?>