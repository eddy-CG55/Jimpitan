<?php 
include 'conn.php';
 
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($kon, $_POST['username']);
    $password = mysqli_real_escape_string($kon, md5($_POST['password']));

    $query = "SELECT * FROM petugas WHERE username= '$username' AND password = '$password'";
    $queryDB = mysqli_query($kon, $query);
    $check = mysqli_num_rows($queryDB);

    if ($check > 0) {
        // ambil data users
        $getData = mysqli_fetch_array($queryDB);
        // set session 
        $_SESSION['id'] = $getData;
        $_SESSION['is_login']  = true;

        header("location: index.php");
    } else {
        echo "Email atau password yang anda masukkan salah";
    }
} else {
    return "Anda tidak di ijinkan";
} 
?>