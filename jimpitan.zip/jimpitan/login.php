<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Jimpitan</title>
    <link rel="icon" href="assets/logo.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <style>
        html,
body {
  height: 100%;
}

body {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-align: center;
  align-items: center;
  padding-top: 40px;
  padding-bottom: 40px;
  background: radial-gradient(circle, #5c0067 0%, #00d4ff 100%);
}

.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 10px 10px;
  margin: 10px auto;

}
.form-signin .checkbox {
  font-weight: 400;

}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
    </style>
</head>
<body class="text-center">

    <form class="form-signin" action="function.php" method="post">
      <div class="card">
      <div class="card-header bg-light" style="font-style: italic; font-family: brush script mt; font-size: 19px;">
         Silakan LOGIN
      </div>
      <div class="card-body">
      <div class="form-group mb-2">
        <label for="inputuser" class="sr-only">Username</label>
        <input type="text" id="inputuser" name="username" id="username" class="form-control" placeholder="Username" required autofocus>
      </div>
      <div class="form-group mb-2">
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" name="password" id="password" class="form-control" placeholder="Password" required>
      </div>
      <button class="btn btn-warning btn-block" name="login" style="font-weight:700;" type="submit">Sign in</button>
      </div>
      </div>
    </form>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>