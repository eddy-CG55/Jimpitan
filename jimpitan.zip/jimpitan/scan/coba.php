<?php
$con = mysqli_connect("localhost", "root", "", "jimpitan");
	$data = [];
	// $tahun = $_POST['tahun'];
	// $bulan = $_POST['bulan'];
 //    $gang = $_POST['gang'];

	$query = mysqli_query($con, "SELECT dj.id_warga,dw.nama,minggu FROM data_jimpitan dj join data_warga dw on dj.id_warga = dw.id_warga ORDER BY dw.id_warga DESC ");
	
	while($row = mysqli_fetch_array($query)){
		$nama = $row['nama'];
		$data[$nama][$row['minggu']] = [$row['minggu']];

	}
	// var_dump($data);
	// $row = mysqli_fetch_array($query);
	// foreach ($row as $key => $jancuk ) {
	// 	foreach ($jancuk as $key => $telo) {
	// 		var_dump($key);
	// 	}
	// }
	echo "<pre>";
	var_dump($data);
	echo "</pre>";
	// echo json_encode($data);
