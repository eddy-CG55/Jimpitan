<?php
$con = mysqli_connect("localhost", "root", "", "bisa");
// $lp = mysqli_query($con, )


	$data = [];
	$id = $_POST['id'];
	// $id = 11;
	$query = mysqli_query($con, "SELECT * FROM anggota where id = '$id' ORDER BY id DESC ");
	while($row = mysqli_fetch_object($query)){
		$id = $row->id;
		$nama = $row->nama;
		$D = date("Y-m-d");
		
	}
	if(!mysqli_num_rows(mysqli_query($con,"SELECT nama FROM laporan WHERE nama = '$nama' AND tgl = '$D'"))){
	$query = mysqli_query($con,"INSERT INTO laporan values('','$id','$nama','$D')");
	}if ($query) {
	  echo '<script language="javascript" type="text/javascript">
      alert("Data Berhasil Di tambahkan");</script>';
	}else{
	  echo "data gagal";
	}
	// var_dump($query);
	// var_dump($data->id); 
	// echo json_encode($data);
