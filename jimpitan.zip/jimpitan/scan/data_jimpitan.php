<?php
$con = mysqli_connect("localhost", "root", "", "jimpitan");
	$data = [];
	$tahun = $_POST['tahun'];
	$bulan = $_POST['bulan'];
    $gang = $_POST['gang'];

	$query = mysqli_query($con, "SELECT dj.id_warga,dw.nama,minggu FROM data_jimpitan dj join data_warga dw on dj.id_warga = dw.id_warga where tahun = '$tahun' and bulan = '$bulan' and gang = '$gang' ORDER BY dw.id_warga DESC ");
	
	while($row = mysqli_fetch_object($query)){
		$data[] = $row;
	}
	// var_dump($data);
	// $row = mysqli_fetch_object($query);
	// foreach ($row as $key) {
	// 	foreach ($key as $key => $telo) {
	// 		var_dump($key);
	// 	}
	// }
	// <!-- var_dump($data); -->
	echo json_encode($data);
