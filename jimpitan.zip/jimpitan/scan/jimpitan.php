<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Data Jimpitan</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/bootstrap-datepicker.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container" id="QR-Code">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="navbar-form navbar-left">
                        <h4>Test Data Jimpitan LPP Puspa Sari</h4>
                    </div>
                </div>
                <div class="panel-body text-center">
                   
                    <div class="container">
                            <div class="col-xs-12">
                                <div class="col-xs-3">
                                    <div class="input-group">
                                      <input type="text" class="form-control" id="tahun" name="tahun" placeholder="Tahun">
                                    </div>
                                </div>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                      <input type="text" class="form-control" id="bulan" name="bulan" placeholder="Bulan">
                                    </div>
                                </div>
                                <div class="col-xs-3">
                                    <div class="input-group">
                                      <select class="form-control" id="gang" name="gang">
                                          <option value="0">Pilih Gang</option>
                                          <option value="Lor">Lor</option>
                                          <option value="Tengah">Tengah</option>
                                          <option value="Kidul">Kidul</option>
                                      </select>
                                    </div>
                                </div>
                                <div class="col-xs-3">
                                    <button type="button" onclick="return cari();" class="btn btn-default">CARI</button>
                                </div>
                            </div>
                        </br>
                            <div class="col-md-12">
                                <div class="row">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr class="thead-dark">
                                                <th>Nama</th>
                                                <th>Minggu (1,2,3,4)</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>  
                        </div>
                </div>
            </div>
        <!-- Using jquery version: -->
        
        <script type="text/javascript" src="js/jquery.js"></script>
            <!-- <script type="text/javascript" src="js/qrcodelib.js"></script>
            <script type="text/javascript" src="js/webcodecamjquery.js"></script>
            <script type="text/javascript" src="js/mainjquery.js"></script> -->
        
        <script type="text/javascript" src="js/qrcodelib.js"></script>
        <script type="text/javascript" src="js/webcodecamjs.js"></script>
        <script type="text/javascript" src="js/bootstrap-datepicker.min.js"></script>
        <script type="text/javascript">
          $("#bulan").datepicker({
            format: "MM",
            viewMode: "months",
            minViewMode: "months",
            maxViewMode: "months",
            autoclose: true
          })
        </script>
        <script type="text/javascript">
          $("#tahun").datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years",
            autoclose: true
          });
        </script>
        <script type="text/javascript">
            function cari(argument) {
                var tahun = $('#tahun').val()
                bulan = $('#bulan').val()
                gang = $('#gang').val();
                // console.log(tahun);
                if (tahun == "" || bulan == "" || gang == "") {
                    alert('mohon masukan tahun bulan dan gang');
                }else{
                    if (bulan != "") {
                        var bln = $("#bulan").data("datepicker").getDate().getMonth() + 1;
                    }
                    $.ajax({
                            url: 'data_jimpitan.php',
                            method : 'POST',
                            data: {tahun: tahun,bulan: bln,gang: gang},
                            success: function(response){
                                var todos = JSON.parse(response);
                                $(".telo").remove();
                                todos.forEach(function(value, index){
                                    
                                    $("tbody").append(`
                                    <tr class="telo">
                                        <td>${value.nama}</td>
                                        <td>${value.minggu}</td>
                                    </tr>`);    
                                })
                            }
                    })
                }
                
            }
            
            

        </script>
    </body>
</html>