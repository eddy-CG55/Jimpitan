$('#jenis').on('change', function () {
    var jenis = $('#jenis').val();
    // alert("Value: " + status);
    if (jenis == '1') {
        $("#kab").show();
        $("#tipe_kab").show();
        $("#tipe_per").hide();
        $("#bln").hide();
        $("#thn").hide();
    } else if(jenis == '2') {
        $("#kab").hide();
        $("#tipe_kab").hide();
        $("#tipe_per").show();
        $("#bln").show();
        $("#thn").show();
    } else {
        $("#tipe_kab").hide();
        $("#tipe_per").hide();
        $("#bln").hide();
        $("#thn").hide();
        $("#kab").hide();
    }
});